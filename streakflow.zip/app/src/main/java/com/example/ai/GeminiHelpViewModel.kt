package com.example.ai

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ChatMessageEntity
import com.example.data.local.StreakFlowDatabase
import com.example.data.repository.StreakFlowRepository
import com.google.firebase.Firebase
import com.google.firebase.ai.Chat
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.content
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout

private const val TAG = "GeminiHelpViewModel"

data class ChatMessage(
    val id: Long,
    val isUser: Boolean,
    val text: String,
    val isStreaming: Boolean = false
)

sealed interface GeminiChatStatus {
    data object Idle : GeminiChatStatus
    data object Loading : GeminiChatStatus
    data object Streaming : GeminiChatStatus
    data class Error(val message: String) : GeminiChatStatus
}

data class GeminiHelpUiState(
    val messages: List<ChatMessage> = emptyList(),
    val status: GeminiChatStatus = GeminiChatStatus.Idle
) {
    val isBusy: Boolean
        get() = status is GeminiChatStatus.Loading || status is GeminiChatStatus.Streaming
}

class GeminiHelpViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = StreakFlowRepository(
        dao = StreakFlowDatabase.getInstance(application).streakFlowDao(),
        context = application
    )

    private val model by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            systemInstruction = content {
                text(
                    """
                    You are the friendly, concise in-app Help Assistant & Habit Coach for StreakFlow, a modern Android habit tracker.
                    Help users understand StreakFlow features and build better daily routines:
                    - Today tab: Daily habit checklist, Today's Progress circular ring, +50 XP per completed task (1 level every 200 XP), 🔥 streak counters, swipe left to delete habits, and "+" button to create custom habits.
                    - Goal Packs tab: 1-click ready-made plans ("Weight Loss Plan", "Exam Topper Routine", "Islamic Routine", "Dopamine Detox") that add curated habits directly to Today.
                    - Quit Timer tab: Live stopwatch tracking Days, Hours, Minutes, and Seconds since quitting a bad habit (such as Junk Food or Social Media), with milestones, personal best, and Reset button.
                    - Daily Reminders: Bell pill in the top bar uses Android AlarmManager to send a daily reminder notification at the user's chosen time.
                    Keep answers clear, actionable, warm, and reasonably short (2-5 sentences or compact bullets).
                    """.trimIndent()
                )
            }
        )
    }

    private var chatSession: Chat? = null
    private val streamingMessage = MutableStateFlow<ChatMessage?>(null)
    private val chatStatus = MutableStateFlow<GeminiChatStatus>(GeminiChatStatus.Idle)

    val uiState: StateFlow<GeminiHelpUiState> = combine(
        repository.chatMessagesFlow,
        streamingMessage,
        chatStatus
    ) { persistedEntities, streaming, status ->
        val persisted = persistedEntities.map { entity ->
            ChatMessage(
                id = entity.id,
                isUser = entity.isUser,
                text = entity.text,
                isStreaming = false
            )
        }
        val combinedMessages = if (streaming != null) {
            persisted + streaming
        } else {
            persisted
        }
        GeminiHelpUiState(
            messages = combinedMessages,
            status = status
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = GeminiHelpUiState()
    )

    fun sendMessage(
        rawPrompt: String,
        userContextSummary: String
    ) {
        val prompt = rawPrompt.trim()
        if (prompt.isEmpty() || uiState.value.isBusy) return

        viewModelScope.launch {
            val persistedHistoryBefore = repository.getChatMessagesOnce()
            val userMsgId = repository.insertChatMessage(isUser = true, text = prompt)
            executeAssistantTurn(
                prompt = prompt,
                userContextSummary = userContextSummary,
                persistedHistoryBefore = persistedHistoryBefore,
                userMessageIdForRollback = userMsgId
            )
        }
    }

    fun retryLastMessage(userContextSummary: String) {
        if (uiState.value.isBusy) return
        viewModelScope.launch {
            val allMessages = repository.getChatMessagesOnce()
            val lastUserMsg = allMessages.lastOrNull { it.isUser } ?: return@launch
            // Remove any trailing assistant messages after lastUserMsg if present, keep lastUserMsg
            val historyBefore = allMessages.takeWhile { it.id != lastUserMsg.id }
            executeAssistantTurn(
                prompt = lastUserMsg.text,
                userContextSummary = userContextSummary,
                persistedHistoryBefore = historyBefore,
                userMessageIdForRollback = lastUserMsg.id
            )
        }
    }

    fun resetChat() {
        chatSession = null
        streamingMessage.value = null
        chatStatus.value = GeminiChatStatus.Idle
        viewModelScope.launch {
            repository.clearChatMessages()
        }
    }

    private suspend fun executeAssistantTurn(
        prompt: String,
        userContextSummary: String,
        persistedHistoryBefore: List<ChatMessageEntity>,
        userMessageIdForRollback: Long
    ) {
        chatStatus.value = GeminiChatStatus.Loading
        streamingMessage.value = ChatMessage(
            id = -1L,
            isUser = false,
            text = "",
            isStreaming = true
        )

        val accumulated = StringBuilder()
        try {
            val chat = chatSession ?: model.startChat(
                history = buildAlternatingHistory(persistedHistoryBefore)
            ).also { chatSession = it }

            val messageToSend = if (persistedHistoryBefore.isEmpty()) {
                "[App Context: $userContextSummary]\n\nUser Question: $prompt"
            } else {
                prompt
            }

            withTimeout(60_000L) {
                chat.sendMessageStream(messageToSend).collect { chunk ->
                    val chunkText = chunk.text.orEmpty()
                    if (chunkText.isNotEmpty()) {
                        accumulated.append(chunkText)
                        streamingMessage.value = ChatMessage(
                            id = -1L,
                            isUser = false,
                            text = accumulated.toString(),
                            isStreaming = true
                        )
                        chatStatus.value = GeminiChatStatus.Streaming
                    }
                }
            }

            val finalText = accumulated.toString().trim()
            if (finalText.isNotBlank()) {
                repository.insertChatMessage(isUser = false, text = finalText)
                streamingMessage.value = null
                chatStatus.value = GeminiChatStatus.Idle
            } else {
                chatSession = null
                streamingMessage.value = null
                chatStatus.value = GeminiChatStatus.Error(
                    "Gemini returned an empty response. Please try again."
                )
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Gemini help chat timed out", e)
            chatSession = null
            streamingMessage.value = null
            chatStatus.value = GeminiChatStatus.Error(
                "Request timed out after 60 seconds. Please try again."
            )
        } catch (e: CancellationException) {
            chatSession = null
            streamingMessage.value = null
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Gemini help chat failed (userMsgId=$userMessageIdForRollback)", e)
            chatSession = null
            streamingMessage.value = null
            chatStatus.value = GeminiChatStatus.Error(
                e.localizedMessage ?: "Unable to reach Gemini right now."
            )
        }
    }

    private fun buildAlternatingHistory(entities: List<ChatMessageEntity>): List<Content> {
        val clean = mutableListOf<Content>()
        var expectUser = true
        for (entity in entities) {
            if (entity.text.isBlank()) continue
            if (entity.isUser == expectUser) {
                clean.add(content(if (entity.isUser) "user" else "model") { text(entity.text) })
                expectUser = !expectUser
            }
        }
        // History passed to startChat should end on a model turn
        if (clean.isNotEmpty() && !expectUser) {
            clean.removeAt(clean.lastIndex)
        }
        return clean
    }
}
