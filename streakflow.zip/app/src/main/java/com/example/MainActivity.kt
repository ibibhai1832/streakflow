package com.example

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesomeMosaic
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesomeMosaic
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ads.RewardedVideoHelper
import com.example.ads.StartIoBannerBar
import com.example.ai.GeminiHelpViewModel
import com.example.ai.configureAppCheck
import com.example.ui.components.AddHabitSheet
import com.example.ui.components.GeminiHelpSheet
import com.example.ui.components.ReminderSettingsSheet
import com.example.ui.components.TopXpHeader
import com.example.ui.screens.GoalPacksScreen
import com.example.ui.screens.QuitTimerScreen
import com.example.ui.screens.TodayScreen
import com.example.ui.theme.BorderHairline
import com.example.ui.theme.CanvasWhite
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.InkSecondary
import com.example.ui.theme.StreakFlowTheme
import com.example.ui.theme.SurfaceWhite
import com.example.ui.viewmodel.StreakFlowViewModel
import com.example.ui.viewmodel.StreakTab
import com.example.ui.viewmodel.StreakUiEvent
import com.startapp.sdk.adsbase.StartAppSDK
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Configure Firebase App Check with launch intent before any UI or ViewModels
        configureAppCheck(this, intent)

        // Initialize Start.io (StartApp) In-App SDK
        StartAppSDK.init(this, "210305948", false)

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(
                Color.WHITE,
                Color.WHITE
            ),
            navigationBarStyle = SystemBarStyle.light(
                Color.WHITE,
                Color.WHITE
            )
        )
        setContent {
            StreakFlowTheme {
                StreakFlowApp()
            }
        }
    }
}

@Composable
fun StreakFlowApp(
    viewModel: StreakFlowViewModel = viewModel(),
    geminiViewModel: GeminiHelpViewModel = viewModel()
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val reminderSettings by viewModel.reminderSettings.collectAsStateWithLifecycle()
    val geminiUiState by geminiViewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    val rewardedVideoHelper = remember(context) {
        RewardedVideoHelper(context).apply { preload() }
    }

    var showAddHabitSheet by remember { mutableStateOf(false) }
    var showReminderSheet by remember { mutableStateOf(false) }
    var showGeminiHelpSheet by remember { mutableStateOf(false) }
    var showXpBurst by remember { mutableStateOf(false) }
    var xpBurstAmount by remember { mutableIntStateOf(50) }
    var isBonusAdLoading by remember { mutableStateOf(false) }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.refreshDayState()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    if (selectedTab != StreakTab.TODAY) {
        BackHandler {
            viewModel.selectTab(StreakTab.TODAY)
        }
    }

    LaunchedEffect(showXpBurst) {
        if (showXpBurst) {
            delay(1300L)
            showXpBurst = false
        }
    }

    LaunchedEffect(Unit) {
        viewModel.events.collect { event ->
            when (event) {
                is StreakUiEvent.XpChanged -> {
                    if (event.delta > 0) {
                        xpBurstAmount = event.delta
                        showXpBurst = false
                        showXpBurst = true
                    }
                }
                is StreakUiEvent.HabitDeleted -> {
                    snackbarHostState.currentSnackbarData?.dismiss()
                    val result = snackbarHostState.showSnackbar(
                        message = "Removed \"${event.habit.title}\"",
                        actionLabel = "Undo",
                        duration = SnackbarDuration.Short
                    )
                    if (result == SnackbarResult.ActionPerformed) {
                        viewModel.restoreHabit(event.habit)
                    }
                }
                is StreakUiEvent.PackStarted -> {
                    snackbarHostState.currentSnackbarData?.dismiss()
                    val message = if (event.addedCount > 0) {
                        "Added ${event.addedCount} habits from ${event.packTitle}"
                    } else {
                        "${event.packTitle} habits are already in Today"
                    }
                    val result = snackbarHostState.showSnackbar(
                        message = message,
                        actionLabel = "Today",
                        duration = SnackbarDuration.Short
                    )
                    if (result == SnackbarResult.ActionPerformed) {
                        viewModel.selectTab(StreakTab.TODAY)
                    }
                }
                is StreakUiEvent.Message -> {
                    snackbarHostState.currentSnackbarData?.dismiss()
                    snackbarHostState.showSnackbar(
                        message = event.text,
                        duration = SnackbarDuration.Short
                    )
                }
            }
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 600.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = CanvasWhite,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                TopXpHeader(
                    userStats = uiState.userStats,
                    dateLabel = uiState.todayDateLabel,
                    showXpBurst = showXpBurst,
                    xpBurstAmount = xpBurstAmount,
                    reminderSettings = reminderSettings,
                    isBonusAdLoading = isBonusAdLoading,
                    onWatchBonusXpAd = {
                        rewardedVideoHelper.showOrLoadAndShow(
                            onLoadingChanged = { loading -> isBonusAdLoading = loading },
                            onRewardEarned = { viewModel.awardBonusXp(100) },
                            onError = { errorMsg ->
                                coroutineScope.launch {
                                    snackbarHostState.currentSnackbarData?.dismiss()
                                    snackbarHostState.showSnackbar(
                                        message = errorMsg,
                                        duration = SnackbarDuration.Short
                                    )
                                }
                            }
                        )
                    },
                    onOpenReminders = { showReminderSheet = true },
                    onOpenGeminiHelp = { showGeminiHelpSheet = true }
                )
            },
            floatingActionButton = {
                if (selectedTab == StreakTab.TODAY) {
                    FloatingActionButton(
                        onClick = { showAddHabitSheet = true },
                        shape = CircleShape,
                        containerColor = EmeraldPrimary,
                        contentColor = SurfaceWhite,
                        elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 4.dp),
                        modifier = Modifier.testTag("add_habit_fab")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = stringResource(R.string.add_habit)
                        )
                    }
                }
            },
            bottomBar = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SurfaceWhite)
                ) {
                    StartIoBannerBar()
                    if (!useNavigationRail) {
                        StreakBottomBar(
                            selectedTab = selectedTab,
                            onSelectTab = viewModel::selectTab
                        )
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavigationRail) {
                    StreakNavigationRail(
                        selectedTab = selectedTab,
                        onSelectTab = viewModel::selectTab
                    )
                }

                when (selectedTab) {
                    StreakTab.TODAY -> TodayScreen(
                        uiState = uiState,
                        onToggleHabit = viewModel::toggleHabit,
                        onDeleteHabit = viewModel::deleteHabit,
                        onOpenAddHabit = { showAddHabitSheet = true },
                        onNavigateToPacks = { viewModel.selectTab(StreakTab.GOAL_PACKS) },
                        modifier = Modifier.weight(1f)
                    )
                    StreakTab.GOAL_PACKS -> GoalPacksScreen(
                        existingHabitTitlesLower = uiState.existingHabitTitlesLower,
                        onStartPack = viewModel::startGoalPack,
                        modifier = Modifier.weight(1f)
                    )
                    StreakTab.QUIT_TIMER -> QuitTimerScreen(
                        trackers = uiState.quitTrackers,
                        activeTracker = uiState.activeQuitTracker,
                        onSelectTracker = viewModel::selectQuitTracker,
                        onResetTracker = viewModel::resetQuitTracker,
                        onAddTracker = viewModel::addQuitTracker,
                        onDeleteTracker = viewModel::deleteQuitTracker,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }

    if (showAddHabitSheet) {
        AddHabitSheet(
            onDismiss = { showAddHabitSheet = false },
            onCreateHabit = { title, category ->
                viewModel.addCustomHabit(title, category)
            }
        )
    }

    if (showReminderSheet) {
        ReminderSettingsSheet(
            settings = reminderSettings,
            onEnableReminder = viewModel::enableDailyReminder,
            onDisableReminder = viewModel::disableDailyReminder,
            onSendTestReminder = viewModel::sendTestReminder,
            onDismiss = { showReminderSheet = false }
        )
    }

    if (showGeminiHelpSheet) {
        val contextSummary = viewModel.buildGeminiUserContext()
        GeminiHelpSheet(
            uiState = geminiUiState,
            userContextSummary = contextSummary,
            onSendMessage = { prompt ->
                geminiViewModel.sendMessage(prompt, contextSummary)
            },
            onRetry = {
                geminiViewModel.retryLastMessage(contextSummary)
            },
            onResetChat = geminiViewModel::resetChat,
            onDismiss = { showGeminiHelpSheet = false }
        )
    }
}

@Composable
private fun StreakBottomBar(
    selectedTab: StreakTab,
    onSelectTab: (StreakTab) -> Unit
) {
    Column {
        HorizontalDivider(thickness = 1.dp, color = BorderHairline)
        NavigationBar(
            containerColor = SurfaceWhite,
            tonalElevation = 0.dp
        ) {
            val itemColors = NavigationBarItemDefaults.colors(
                selectedIconColor = EmeraldDeep,
                selectedTextColor = EmeraldDeep,
                indicatorColor = EmeraldSoft,
                unselectedIconColor = InkSecondary,
                unselectedTextColor = InkSecondary
            )

            NavigationBarItem(
                selected = selectedTab == StreakTab.TODAY,
                onClick = { onSelectTab(StreakTab.TODAY) },
                icon = {
                    Icon(
                        imageVector = if (selectedTab == StreakTab.TODAY) Icons.Rounded.CheckCircle else Icons.Outlined.CheckCircle,
                        contentDescription = stringResource(R.string.nav_today)
                    )
                },
                label = { Text(stringResource(R.string.nav_today)) },
                colors = itemColors,
                modifier = Modifier.testTag("nav_tab_today")
            )
            NavigationBarItem(
                selected = selectedTab == StreakTab.GOAL_PACKS,
                onClick = { onSelectTab(StreakTab.GOAL_PACKS) },
                icon = {
                    Icon(
                        imageVector = if (selectedTab == StreakTab.GOAL_PACKS) Icons.Rounded.AutoAwesomeMosaic else Icons.Outlined.AutoAwesomeMosaic,
                        contentDescription = stringResource(R.string.nav_goal_packs)
                    )
                },
                label = { Text(stringResource(R.string.nav_goal_packs)) },
                colors = itemColors,
                modifier = Modifier.testTag("nav_tab_packs")
            )
            NavigationBarItem(
                selected = selectedTab == StreakTab.QUIT_TIMER,
                onClick = { onSelectTab(StreakTab.QUIT_TIMER) },
                icon = {
                    Icon(
                        imageVector = if (selectedTab == StreakTab.QUIT_TIMER) Icons.Rounded.Timer else Icons.Outlined.Timer,
                        contentDescription = stringResource(R.string.nav_quit_timer)
                    )
                },
                label = { Text(stringResource(R.string.nav_quit_timer)) },
                colors = itemColors,
                modifier = Modifier.testTag("nav_tab_quit")
            )
        }
    }
}

@Composable
private fun StreakNavigationRail(
    selectedTab: StreakTab,
    onSelectTab: (StreakTab) -> Unit
) {
    NavigationRail(
        containerColor = SurfaceWhite
    ) {
        val railColors = NavigationRailItemDefaults.colors(
            selectedIconColor = EmeraldDeep,
            selectedTextColor = EmeraldDeep,
            indicatorColor = EmeraldSoft,
            unselectedIconColor = InkSecondary,
            unselectedTextColor = InkSecondary
        )
        NavigationRailItem(
            selected = selectedTab == StreakTab.TODAY,
            onClick = { onSelectTab(StreakTab.TODAY) },
            icon = {
                Icon(
                    imageVector = if (selectedTab == StreakTab.TODAY) Icons.Rounded.CheckCircle else Icons.Outlined.CheckCircle,
                    contentDescription = stringResource(R.string.nav_today)
                )
            },
            label = { Text(stringResource(R.string.nav_today)) },
            colors = railColors,
            modifier = Modifier.testTag("nav_tab_today")
        )
        NavigationRailItem(
            selected = selectedTab == StreakTab.GOAL_PACKS,
            onClick = { onSelectTab(StreakTab.GOAL_PACKS) },
            icon = {
                Icon(
                    imageVector = if (selectedTab == StreakTab.GOAL_PACKS) Icons.Rounded.AutoAwesomeMosaic else Icons.Outlined.AutoAwesomeMosaic,
                    contentDescription = stringResource(R.string.nav_goal_packs)
                )
            },
            label = { Text(stringResource(R.string.nav_goal_packs)) },
            colors = railColors,
            modifier = Modifier.testTag("nav_tab_packs")
        )
        NavigationRailItem(
            selected = selectedTab == StreakTab.QUIT_TIMER,
            onClick = { onSelectTab(StreakTab.QUIT_TIMER) },
            icon = {
                Icon(
                    imageVector = if (selectedTab == StreakTab.QUIT_TIMER) Icons.Rounded.Timer else Icons.Outlined.Timer,
                    contentDescription = stringResource(R.string.nav_quit_timer)
                )
            },
            label = { Text(stringResource(R.string.nav_quit_timer)) },
            colors = railColors,
            modifier = Modifier.testTag("nav_tab_quit")
        )
    }
}
