package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_stats")
data class UserStatsEntity(
    @PrimaryKey val id: Int = 1,
    val totalXp: Int = 0,
    val lastActiveDate: String = ""
) {
    val level: Int
        get() = (totalXp / XP_PER_LEVEL) + 1

    val xpInCurrentLevel: Int
        get() = totalXp % XP_PER_LEVEL

    val levelProgress: Float
        get() = xpInCurrentLevel.toFloat() / XP_PER_LEVEL.toFloat()

    companion object {
        const val XP_PER_LEVEL = 200
        const val XP_PER_HABIT = 50
    }
}
