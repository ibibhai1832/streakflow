package com.example.data.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.FlameDeep
import com.example.ui.theme.FlameOrange
import com.example.ui.theme.FlameSoft
import com.example.ui.theme.IndigoAccent
import com.example.ui.theme.IndigoDeep
import com.example.ui.theme.IndigoSoft

data class PackHabitTemplate(
    val title: String,
    val category: String
)

data class GoalPack(
    val id: String,
    val title: String,
    val subtitle: String,
    val tag: String,
    val accentColor: Color,
    val softContainerColor: Color,
    val deepInkColor: Color,
    val habits: List<PackHabitTemplate>
)

object GoalPackCatalog {
    val packs: List<GoalPack> = listOf(
        GoalPack(
            id = "weight_loss",
            title = "Weight Loss Plan",
            subtitle = "Sustainable daily movement, hydration, and clean eating habits.",
            tag = "Fitness & Nutrition",
            accentColor = EmeraldPrimary,
            softContainerColor = EmeraldSoft,
            deepInkColor = EmeraldDeep,
            habits = listOf(
                PackHabitTemplate("Walk 10,000 Steps", "Fitness"),
                PackHabitTemplate("Drink 3L Water", "Health"),
                PackHabitTemplate("Zero Added Sugar", "Nutrition"),
                PackHabitTemplate("30-Min Cardio Session", "Fitness"),
                PackHabitTemplate("High-Protein Breakfast", "Nutrition")
            )
        ),
        GoalPack(
            id = "exam_topper",
            title = "Exam Topper Routine",
            subtitle = "High-retention study blocks, active recall, and sharp focus.",
            tag = "Academic Excellence",
            accentColor = IndigoAccent,
            softContainerColor = IndigoSoft,
            deepInkColor = IndigoDeep,
            habits = listOf(
                PackHabitTemplate("2h Deep Study Block", "Study"),
                PackHabitTemplate("Active Recall Flashcards", "Study"),
                PackHabitTemplate("Solve 1 Past Paper Set", "Study"),
                PackHabitTemplate("Phone-Free Study Desk", "Focus"),
                PackHabitTemplate("15-Min Nightly Note Review", "Study")
            )
        ),
        GoalPack(
            id = "islamic_routine",
            title = "Islamic Routine",
            subtitle = "Anchor your day with prayer, remembrance, Quran, and gratitude.",
            tag = "Faith & Mindfulness",
            accentColor = Color(0xFF0D9488),
            softContainerColor = Color(0xFFCCFBF1),
            deepInkColor = Color(0xFF115E59),
            habits = listOf(
                PackHabitTemplate("Pray 5 Daily Prayers on Time", "Faith"),
                PackHabitTemplate("Morning & Evening Adhkar", "Faith"),
                PackHabitTemplate("Read 2 Pages of Quran", "Faith"),
                PackHabitTemplate("Daily Sadaqah or Kind Act", "Mindfulness"),
                PackHabitTemplate("Gratitude Dua Before Sleep", "Faith")
            )
        ),
        GoalPack(
            id = "dopamine_detox",
            title = "Dopamine Detox",
            subtitle = "Reset attention span, cut mindless scrolling, and reclaim clarity.",
            tag = "Digital Reset",
            accentColor = FlameOrange,
            softContainerColor = FlameSoft,
            deepInkColor = FlameDeep,
            habits = listOf(
                PackHabitTemplate("No Social Media Until Noon", "Focus"),
                PackHabitTemplate("Screen-Free First 60 Mins", "Mindfulness"),
                PackHabitTemplate("Read Physical Book 20 Mins", "Growth"),
                PackHabitTemplate("15-Min Outdoor Sunlight Walk", "Health"),
                PackHabitTemplate("No Screens 1h Before Bed", "Sleep")
            )
        )
    )
}
