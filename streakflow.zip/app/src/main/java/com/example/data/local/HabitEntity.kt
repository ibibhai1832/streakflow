package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "habits")
data class HabitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    val category: String,
    val streak: Int = 0,
    val isCompletedToday: Boolean = false,
    val lastCompletedDate: String? = null,
    val packId: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
