package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface StreakFlowDao {
    @Query("SELECT * FROM habits ORDER BY isCompletedToday ASC, createdAt DESC")
    fun observeHabits(): Flow<List<HabitEntity>>

    @Query("SELECT * FROM habits")
    suspend fun getAllHabitsOnce(): List<HabitEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHabit(habit: HabitEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHabits(habits: List<HabitEntity>)

    @Update
    suspend fun updateHabit(habit: HabitEntity)

    @Update
    suspend fun updateHabits(habits: List<HabitEntity>)

    @Delete
    suspend fun deleteHabit(habit: HabitEntity)

    @Query("SELECT * FROM user_stats WHERE id = 1")
    fun observeUserStats(): Flow<UserStatsEntity?>

    @Query("SELECT * FROM user_stats WHERE id = 1")
    suspend fun getUserStatsOnce(): UserStatsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertUserStats(stats: UserStatsEntity)

    @Query("SELECT * FROM quit_trackers ORDER BY id ASC")
    fun observeQuitTrackers(): Flow<List<QuitTimerEntity>>

    @Query("SELECT * FROM quit_trackers ORDER BY id ASC")
    suspend fun getQuitTrackersOnce(): List<QuitTimerEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuitTracker(tracker: QuitTimerEntity): Long

    @Update
    suspend fun updateQuitTracker(tracker: QuitTimerEntity)

    @Query("UPDATE quit_trackers SET isSelected = (id = :selectedId)")
    suspend fun selectQuitTracker(selectedId: Long)

    @Delete
    suspend fun deleteQuitTracker(tracker: QuitTimerEntity)

    @Query("SELECT * FROM chat_messages ORDER BY createdAt ASC, id ASC")
    fun observeChatMessages(): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM chat_messages ORDER BY createdAt ASC, id ASC")
    suspend fun getChatMessagesOnce(): List<ChatMessageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChatMessage(message: ChatMessageEntity): Long

    @Query("DELETE FROM chat_messages WHERE id = :id")
    suspend fun deleteChatMessageById(id: Long)

    @Query("DELETE FROM chat_messages")
    suspend fun clearChatMessages()
}
