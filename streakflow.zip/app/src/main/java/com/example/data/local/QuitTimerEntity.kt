package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "quit_trackers")
data class QuitTimerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val habitName: String,
    val startTimestampMillis: Long = System.currentTimeMillis(),
    val bestStreakMillis: Long = 0L,
    val isSelected: Boolean = false
)
