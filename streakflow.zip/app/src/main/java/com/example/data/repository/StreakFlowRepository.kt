package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.local.ChatMessageEntity
import com.example.data.local.HabitEntity
import com.example.data.local.QuitTimerEntity
import com.example.data.local.StreakFlowDao
import com.example.data.local.UserStatsEntity
import com.example.data.model.GoalPack
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class StreakFlowRepository(
    private val dao: StreakFlowDao,
    context: Context
) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("streakflow_prefs", Context.MODE_PRIVATE)

    val habitsFlow: Flow<List<HabitEntity>> = dao.observeHabits()

    val userStatsFlow: Flow<UserStatsEntity> = dao.observeUserStats().map { stats ->
        stats ?: UserStatsEntity(id = 1, totalXp = 0, lastActiveDate = todayKey())
    }

    val quitTrackersFlow: Flow<List<QuitTimerEntity>> = dao.observeQuitTrackers()

    val chatMessagesFlow: Flow<List<ChatMessageEntity>> = dao.observeChatMessages()

    suspend fun ensureInitializedAndRollOverDay() {
        val today = todayKey()
        val isInitialized = prefs.getBoolean(KEY_INITIALIZED, false)

        if (!isInitialized) {
            val existingHabits = dao.getAllHabitsOnce()
            if (existingHabits.isEmpty()) {
                dao.insertHabits(
                    listOf(
                        HabitEntity(title = "Drink 2L Water", category = "Health", streak = 0),
                        HabitEntity(title = "20-Min Morning Walk", category = "Fitness", streak = 0),
                        HabitEntity(title = "Read 10 Pages", category = "Growth", streak = 0)
                    )
                )
            }
            if (dao.getUserStatsOnce() == null) {
                dao.upsertUserStats(UserStatsEntity(id = 1, totalXp = 0, lastActiveDate = today))
            }
            if (dao.getQuitTrackersOnce().isEmpty()) {
                val now = System.currentTimeMillis()
                dao.insertQuitTracker(
                    QuitTimerEntity(
                        habitName = "Junk Food",
                        startTimestampMillis = now,
                        bestStreakMillis = 0L,
                        isSelected = true
                    )
                )
                dao.insertQuitTracker(
                    QuitTimerEntity(
                        habitName = "Social Media",
                        startTimestampMillis = now,
                        bestStreakMillis = 0L,
                        isSelected = false
                    )
                )
            }
            prefs.edit().putBoolean(KEY_INITIALIZED, true).commit()
            return
        }

        val stats = dao.getUserStatsOnce() ?: UserStatsEntity(id = 1, totalXp = 0, lastActiveDate = today)
        if (stats.lastActiveDate != today) {
            val yesterday = yesterdayKey()
            val allHabits = dao.getAllHabitsOnce()
            val updatedHabits = allHabits.map { habit ->
                val keptStreak = habit.lastCompletedDate == yesterday || habit.lastCompletedDate == today
                habit.copy(
                    isCompletedToday = false,
                    streak = if (keptStreak) habit.streak else 0
                )
            }
            if (updatedHabits.isNotEmpty()) {
                dao.updateHabits(updatedHabits)
            }
            dao.upsertUserStats(stats.copy(lastActiveDate = today))
        }
    }

    suspend fun toggleHabitCompletion(habit: HabitEntity): Int {
        val today = todayKey()
        val currentStats = dao.getUserStatsOnce() ?: UserStatsEntity(id = 1, totalXp = 0, lastActiveDate = today)

        return if (!habit.isCompletedToday) {
            val updatedHabit = habit.copy(
                isCompletedToday = true,
                streak = habit.streak + 1,
                lastCompletedDate = today
            )
            dao.updateHabit(updatedHabit)
            val updatedXp = currentStats.totalXp + UserStatsEntity.XP_PER_HABIT
            dao.upsertUserStats(currentStats.copy(totalXp = updatedXp, lastActiveDate = today))
            UserStatsEntity.XP_PER_HABIT
        } else {
            val updatedHabit = habit.copy(
                isCompletedToday = false,
                streak = (habit.streak - 1).coerceAtLeast(0),
                lastCompletedDate = null
            )
            dao.updateHabit(updatedHabit)
            val updatedXp = (currentStats.totalXp - UserStatsEntity.XP_PER_HABIT).coerceAtLeast(0)
            dao.upsertUserStats(currentStats.copy(totalXp = updatedXp, lastActiveDate = today))
            -UserStatsEntity.XP_PER_HABIT
        }
    }

    suspend fun awardBonusXp(amount: Int): Int {
        if (amount <= 0) return 0
        val today = todayKey()
        val currentStats = dao.getUserStatsOnce() ?: UserStatsEntity(id = 1, totalXp = 0, lastActiveDate = today)
        val updatedXp = currentStats.totalXp + amount
        dao.upsertUserStats(currentStats.copy(totalXp = updatedXp, lastActiveDate = today))
        return amount
    }

    suspend fun addCustomHabit(title: String, category: String) {
        val trimmed = title.trim()
        if (trimmed.isEmpty()) return
        dao.insertHabit(
            HabitEntity(
                title = trimmed,
                category = category.ifBlank { "Custom" },
                streak = 0,
                isCompletedToday = false
            )
        )
    }

    suspend fun restoreHabit(habit: HabitEntity) {
        dao.insertHabit(habit)
    }

    suspend fun deleteHabit(habit: HabitEntity) {
        dao.deleteHabit(habit)
    }

    suspend fun startGoalPack(pack: GoalPack): Int {
        val existingTitles = dao.getAllHabitsOnce()
            .map { it.title.trim().lowercase(Locale.US) }
            .toSet()

        val newHabits = pack.habits
            .filter { it.title.trim().lowercase(Locale.US) !in existingTitles }
            .mapIndexed { index, template ->
                HabitEntity(
                    title = template.title,
                    category = template.category,
                    streak = 0,
                    isCompletedToday = false,
                    packId = pack.id,
                    createdAt = System.currentTimeMillis() + index
                )
            }

        if (newHabits.isNotEmpty()) {
            dao.insertHabits(newHabits)
        }
        return newHabits.size
    }

    suspend fun selectQuitTracker(trackerId: Long) {
        dao.selectQuitTracker(trackerId)
    }

    suspend fun addQuitTracker(habitName: String) {
        val trimmed = habitName.trim()
        if (trimmed.isEmpty()) return
        val newId = dao.insertQuitTracker(
            QuitTimerEntity(
                habitName = trimmed,
                startTimestampMillis = System.currentTimeMillis(),
                bestStreakMillis = 0L,
                isSelected = false
            )
        )
        dao.selectQuitTracker(newId)
    }

    suspend fun resetQuitTracker(tracker: QuitTimerEntity) {
        val now = System.currentTimeMillis()
        val elapsed = (now - tracker.startTimestampMillis).coerceAtLeast(0L)
        val newBest = maxOf(tracker.bestStreakMillis, elapsed)
        dao.updateQuitTracker(
            tracker.copy(
                startTimestampMillis = now,
                bestStreakMillis = newBest
            )
        )
    }

    suspend fun deleteQuitTracker(tracker: QuitTimerEntity) {
        dao.deleteQuitTracker(tracker)
        val remaining = dao.getQuitTrackersOnce()
        if (remaining.isNotEmpty() && remaining.none { it.isSelected }) {
            dao.selectQuitTracker(remaining.first().id)
        }
    }

    suspend fun getChatMessagesOnce(): List<ChatMessageEntity> = dao.getChatMessagesOnce()

    suspend fun insertChatMessage(isUser: Boolean, text: String): Long {
        return dao.insertChatMessage(
            ChatMessageEntity(
                isUser = isUser,
                text = text
            )
        )
    }

    suspend fun deleteChatMessageById(id: Long) {
        dao.deleteChatMessageById(id)
    }

    suspend fun clearChatMessages() {
        dao.clearChatMessages()
    }

    fun todayDisplayDate(): String {
        val formatter = SimpleDateFormat("EEE, MMM d", Locale.getDefault())
        return formatter.format(Date())
    }

    private fun todayKey(): String {
        val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return formatter.format(Date())
    }

    private fun yesterdayKey(): String {
        val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
        val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return formatter.format(cal.time)
    }

    companion object {
        private const val KEY_INITIALIZED = "is_initialized_v1"
    }
}
