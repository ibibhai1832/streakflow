package com.example.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.local.StreakFlowDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class HabitReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val pendingResult = goAsync()
        val appContext = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val habits = StreakFlowDatabase.getInstance(appContext)
                    .streakFlowDao()
                    .getAllHabitsOnce()
                val pendingCount = habits.count { !it.isCompletedToday }
                HabitReminderScheduler.showReminderNotification(
                    context = appContext,
                    pendingHabitsCount = pendingCount,
                    totalHabitsCount = habits.size
                )
                HabitReminderScheduler.rescheduleIfEnabled(appContext)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
