package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ai.ChatMessage
import com.example.ai.GeminiChatStatus
import com.example.ai.GeminiHelpUiState
import com.example.ui.theme.BorderHairline
import com.example.ui.theme.CanvasWhite
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DangerSoft
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.IndigoAccent
import com.example.ui.theme.IndigoDeep
import com.example.ui.theme.IndigoSoft
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkPrimary
import com.example.ui.theme.InkSecondary
import com.example.ui.theme.SurfaceVariantLight
import com.example.ui.theme.SurfaceWhite

private val HelpStarterPrompts = listOf(
    "How do XP & streaks work?",
    "Which Goal Pack fits me best?",
    "Tips to beat junk food cravings",
    "How do daily reminders work?"
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun GeminiHelpSheet(
    uiState: GeminiHelpUiState,
    userContextSummary: String,
    onSendMessage: (String) -> Unit,
    onRetry: () -> Unit,
    onResetChat: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(uiState.messages.size, uiState.messages.lastOrNull()?.text?.length) {
        if (uiState.messages.isNotEmpty()) {
            listState.animateScrollToItem(uiState.messages.lastIndex)
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = CanvasWhite,
        dragHandle = null,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.88f)
                .navigationBarsPadding()
                .imePadding()
        ) {
            // Header
            Surface(color = SurfaceWhite) {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(IndigoSoft),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.AutoAwesome,
                                    contentDescription = null,
                                    tint = IndigoAccent,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = stringResource(R.string.gemini_help_title),
                                    style = MaterialTheme.typography.titleLarge,
                                    color = InkPrimary
                                )
                                Text(
                                    text = "Powered by Gemini",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = IndigoDeep
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (uiState.messages.isNotEmpty()) {
                                IconButton(
                                    onClick = onResetChat,
                                    modifier = Modifier.testTag("gemini_new_chat_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Refresh,
                                        contentDescription = stringResource(R.string.gemini_new_chat),
                                        tint = InkSecondary
                                    )
                                }
                            }
                            IconButton(
                                onClick = onDismiss,
                                modifier = Modifier.testTag("gemini_close_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = "Close help chat",
                                    tint = InkSecondary
                                )
                            }
                        }
                    }
                    HorizontalDivider(thickness = 1.dp, color = BorderHairline)
                }
            }

            // Message List / Welcome View
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (uiState.messages.isEmpty()) {
                    item(key = "welcome_card") {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = SurfaceWhite,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .border(1.dp, BorderHairline, RoundedCornerShape(20.dp))
                                    .padding(18.dp)
                            ) {
                                Text(
                                    text = "Hi! How can I help you today?",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = InkPrimary
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = stringResource(R.string.gemini_help_subtitle),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = InkSecondary
                                )
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    text = "Current snapshot: $userContextSummary",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = IndigoDeep,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(IndigoSoft)
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = "Quick Questions",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = InkSecondary
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    HelpStarterPrompts.forEach { prompt ->
                                        Text(
                                            text = prompt,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = IndigoDeep,
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(SurfaceVariantLight)
                                                .border(1.dp, BorderHairline, RoundedCornerShape(12.dp))
                                                .clickable { onSendMessage(prompt) }
                                                .padding(horizontal = 12.dp, vertical = 9.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else {
                    items(
                        items = uiState.messages,
                        key = { it.id }
                    ) { message ->
                        ChatBubble(message = message)
                    }
                }

                if (uiState.status is GeminiChatStatus.Error) {
                    item(key = "error_banner") {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = DangerSoft,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("gemini_error_banner")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.ErrorOutline,
                                        contentDescription = null,
                                        tint = DangerRed,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = uiState.status.message,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = DangerRed
                                    )
                                }
                                TextButton(
                                    onClick = onRetry,
                                    modifier = Modifier.testTag("gemini_retry_button")
                                ) {
                                    Text("Retry", color = DangerRed)
                                }
                            }
                        }
                    }
                }
            }

            // Input bar
            Surface(color = SurfaceWhite) {
                Column {
                    HorizontalDivider(thickness = 1.dp, color = BorderHairline)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = inputText,
                            onValueChange = { inputText = it },
                            placeholder = {
                                Text(
                                    text = stringResource(R.string.gemini_input_placeholder),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = InkMuted
                                )
                            },
                            maxLines = 3,
                            keyboardOptions = KeyboardOptions(
                                capitalization = KeyboardCapitalization.Sentences,
                                imeAction = ImeAction.Send
                            ),
                            keyboardActions = KeyboardActions(
                                onSend = {
                                    if (inputText.isNotBlank() && !uiState.isBusy) {
                                        onSendMessage(inputText)
                                        inputText = ""
                                    }
                                }
                            ),
                            shape = RoundedCornerShape(22.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = IndigoAccent,
                                unfocusedBorderColor = BorderHairline,
                                cursorColor = IndigoAccent,
                                focusedContainerColor = CanvasWhite,
                                unfocusedContainerColor = CanvasWhite
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("gemini_chat_input")
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        val canSend = inputText.isNotBlank() && !uiState.isBusy
                        IconButton(
                            onClick = {
                                if (canSend) {
                                    onSendMessage(inputText)
                                    inputText = ""
                                }
                            },
                            enabled = canSend,
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(if (canSend) IndigoAccent else SurfaceVariantLight)
                                .testTag("gemini_send_button")
                        ) {
                            if (uiState.isBusy) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp,
                                    color = IndigoAccent
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Rounded.Send,
                                    contentDescription = "Send message",
                                    tint = if (canSend) SurfaceWhite else InkMuted,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatBubble(message: ChatMessage) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!message.isUser) {
            Box(
                modifier = Modifier
                    .padding(top = 4.dp, end = 8.dp)
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(IndigoSoft),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.AutoAwesome,
                    contentDescription = null,
                    tint = IndigoAccent,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Surface(
            shape = RoundedCornerShape(
                topStart = if (message.isUser) 18.dp else 6.dp,
                topEnd = if (message.isUser) 6.dp else 18.dp,
                bottomStart = 18.dp,
                bottomEnd = 18.dp
            ),
            color = if (message.isUser) EmeraldPrimary else SurfaceWhite,
            modifier = Modifier
                .widthIn(max = 300.dp)
                .then(
                    if (!message.isUser) {
                        Modifier.border(
                            1.dp,
                            BorderHairline,
                            RoundedCornerShape(
                                topStart = 6.dp,
                                topEnd = 18.dp,
                                bottomStart = 18.dp,
                                bottomEnd = 18.dp
                            )
                        )
                    } else {
                        Modifier
                    }
                )
        ) {
            Box(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                if (message.text.isEmpty() && message.isStreaming) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(14.dp),
                            strokeWidth = 2.dp,
                            color = IndigoAccent
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Thinking…",
                            style = MaterialTheme.typography.bodyMedium,
                            color = InkSecondary
                        )
                    }
                } else {
                    Text(
                        text = message.text,
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (message.isUser) SurfaceWhite else InkPrimary
                    )
                }
            }
        }
    }
}
