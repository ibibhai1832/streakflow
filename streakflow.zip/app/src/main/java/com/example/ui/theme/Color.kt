package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean White-Theme Palette ("Daylight Kinetic")
val CanvasWhite = Color(0xFFF8FAFC)
val SurfaceWhite = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val BorderHairline = Color(0xFFE2E8F0)

val InkPrimary = Color(0xFF0F172A)
val InkSecondary = Color(0xFF475569)
val InkMuted = Color(0xFF94A3B8)

// Primary Brand Emerald
val EmeraldPrimary = Color(0xFF059669)
val EmeraldBright = Color(0xFF10B981)
val EmeraldSoft = Color(0xFFD1FAE5)
val EmeraldDeep = Color(0xFF065F46)

// Secondary Flame / Streak / XP Accent
val FlameOrange = Color(0xFFF97316)
val FlameAmber = Color(0xFFF59E0B)
val FlameSoft = Color(0xFFFFEDD5)
val FlameDeep = Color(0xFF9A3412)

// Tertiary Indigo Accent (Goal Packs / Focus)
val IndigoAccent = Color(0xFF4F46E5)
val IndigoSoft = Color(0xFFEEF2FF)
val IndigoDeep = Color(0xFF3730A3)

// Semantic Destructive
val DangerRed = Color(0xFFDC2626)
val DangerSoft = Color(0xFFFEE2E2)
