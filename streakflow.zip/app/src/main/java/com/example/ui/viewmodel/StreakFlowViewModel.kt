package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.HabitEntity
import com.example.data.local.QuitTimerEntity
import com.example.data.local.StreakFlowDatabase
import com.example.data.local.UserStatsEntity
import com.example.data.model.GoalPack
import com.example.data.repository.StreakFlowRepository
import com.example.notifications.HabitReminderScheduler
import com.example.notifications.ReminderSettings
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale

enum class StreakTab {
    TODAY,
    GOAL_PACKS,
    QUIT_TIMER
}

data class StreakFlowUiState(
    val habits: List<HabitEntity> = emptyList(),
    val userStats: UserStatsEntity = UserStatsEntity(),
    val quitTrackers: List<QuitTimerEntity> = emptyList(),
    val todayDateLabel: String = "",
    val isLoaded: Boolean = false
) {
    val totalHabitsCount: Int get() = habits.size
    val completedHabitsCount: Int get() = habits.count { it.isCompletedToday }
    val completionProgress: Float
        get() = if (habits.isEmpty()) 0f else completedHabitsCount.toFloat() / habits.size.toFloat()

    val existingHabitTitlesLower: Set<String>
        get() = habits.map { it.title.trim().lowercase(Locale.US) }.toSet()

    val activeQuitTracker: QuitTimerEntity?
        get() = quitTrackers.firstOrNull { it.isSelected } ?: quitTrackers.firstOrNull()
}

sealed interface StreakUiEvent {
    data class XpChanged(val delta: Int) : StreakUiEvent
    data class HabitDeleted(val habit: HabitEntity) : StreakUiEvent
    data class PackStarted(val packTitle: String, val addedCount: Int) : StreakUiEvent
    data class Message(val text: String) : StreakUiEvent
}

class StreakFlowViewModel(application: Application) : AndroidViewModel(application) {
    private val appContext = application.applicationContext
    private val repository: StreakFlowRepository = StreakFlowRepository(
        dao = StreakFlowDatabase.getInstance(application).streakFlowDao(),
        context = application
    )

    private val _selectedTab = MutableStateFlow(StreakTab.TODAY)
    val selectedTab: StateFlow<StreakTab> = _selectedTab.asStateFlow()

    private val _reminderSettings = MutableStateFlow(HabitReminderScheduler.getSettings(appContext))
    val reminderSettings: StateFlow<ReminderSettings> = _reminderSettings.asStateFlow()

    private val _events = MutableSharedFlow<StreakUiEvent>()
    val events: SharedFlow<StreakUiEvent> = _events.asSharedFlow()

    val uiState: StateFlow<StreakFlowUiState> = combine(
        repository.habitsFlow,
        repository.userStatsFlow,
        repository.quitTrackersFlow
    ) { habits, stats, quitTrackers ->
        StreakFlowUiState(
            habits = habits,
            userStats = stats,
            quitTrackers = quitTrackers,
            todayDateLabel = repository.todayDisplayDate(),
            isLoaded = true
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = StreakFlowUiState(todayDateLabel = repository.todayDisplayDate())
    )

    init {
        refreshDayState()
    }

    fun refreshDayState() {
        viewModelScope.launch {
            repository.ensureInitializedAndRollOverDay()
        }
    }

    fun selectTab(tab: StreakTab) {
        _selectedTab.value = tab
    }

    fun toggleHabit(habit: HabitEntity) {
        viewModelScope.launch {
            val xpDelta = repository.toggleHabitCompletion(habit)
            _events.emit(StreakUiEvent.XpChanged(xpDelta))
        }
    }

    fun awardBonusXp(amount: Int = 100) {
        viewModelScope.launch {
            val awarded = repository.awardBonusXp(amount)
            if (awarded > 0) {
                _events.emit(StreakUiEvent.XpChanged(awarded))
                _events.emit(StreakUiEvent.Message("+$awarded Bonus XP earned!"))
            }
        }
    }

    fun addCustomHabit(title: String, category: String) {
        viewModelScope.launch {
            repository.addCustomHabit(title, category)
        }
    }

    fun deleteHabit(habit: HabitEntity) {
        viewModelScope.launch {
            repository.deleteHabit(habit)
            _events.emit(StreakUiEvent.HabitDeleted(habit))
        }
    }

    fun restoreHabit(habit: HabitEntity) {
        viewModelScope.launch {
            repository.restoreHabit(habit)
        }
    }

    fun startGoalPack(pack: GoalPack) {
        viewModelScope.launch {
            val addedCount = repository.startGoalPack(pack)
            _events.emit(StreakUiEvent.PackStarted(pack.title, addedCount))
        }
    }

    fun selectQuitTracker(trackerId: Long) {
        viewModelScope.launch {
            repository.selectQuitTracker(trackerId)
        }
    }

    fun addQuitTracker(habitName: String) {
        viewModelScope.launch {
            repository.addQuitTracker(habitName)
            _events.emit(StreakUiEvent.Message("Started Quit Timer for $habitName"))
        }
    }

    fun resetQuitTracker(tracker: QuitTimerEntity) {
        viewModelScope.launch {
            repository.resetQuitTracker(tracker)
            _events.emit(StreakUiEvent.Message("${tracker.habitName} timer reset"))
        }
    }

    fun deleteQuitTracker(tracker: QuitTimerEntity) {
        viewModelScope.launch {
            repository.deleteQuitTracker(tracker)
        }
    }

    fun enableDailyReminder(hour: Int, minute: Int) {
        val updated = HabitReminderScheduler.enableAndSchedule(appContext, hour, minute)
        _reminderSettings.value = updated
        viewModelScope.launch {
            _events.emit(StreakUiEvent.Message("Daily reminder set for ${updated.formattedTime()}"))
        }
    }

    fun disableDailyReminder() {
        val updated = HabitReminderScheduler.disableAndCancel(appContext)
        _reminderSettings.value = updated
        viewModelScope.launch {
            _events.emit(StreakUiEvent.Message("Daily reminder turned off"))
        }
    }

    fun sendTestReminder() {
        val state = uiState.value
        val pendingCount = state.habits.count { !it.isCompletedToday }
        HabitReminderScheduler.showReminderNotification(
            context = appContext,
            pendingHabitsCount = pendingCount,
            totalHabitsCount = state.totalHabitsCount
        )
        viewModelScope.launch {
            _events.emit(StreakUiEvent.Message("Test reminder notification sent"))
        }
    }

    fun buildGeminiUserContext(): String {
        val state = uiState.value
        val quitName = state.activeQuitTracker?.habitName ?: "None"
        return "Lvl ${state.userStats.level} (${state.userStats.totalXp} XP), " +
            "${state.completedHabitsCount}/${state.totalHabitsCount} habits completed today, " +
            "Active Quit Tracker: $quitName"
    }
}
