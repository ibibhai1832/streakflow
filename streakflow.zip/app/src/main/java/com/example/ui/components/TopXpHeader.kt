package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.UserStatsEntity
import com.example.notifications.ReminderSettings
import com.example.ui.theme.BorderHairline
import com.example.ui.theme.EmeraldBright
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.FlameDeep
import com.example.ui.theme.FlameOrange
import com.example.ui.theme.FlameSoft
import com.example.ui.theme.IndigoAccent
import com.example.ui.theme.IndigoDeep
import com.example.ui.theme.IndigoSoft
import com.example.ui.theme.InkPrimary
import com.example.ui.theme.InkSecondary
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.SurfaceVariantLight
import com.example.ui.theme.SurfaceWhite

@Composable
fun TopXpHeader(
    userStats: UserStatsEntity,
    dateLabel: String,
    showXpBurst: Boolean,
    xpBurstAmount: Int,
    reminderSettings: ReminderSettings,
    isBonusAdLoading: Boolean,
    onWatchBonusXpAd: () -> Unit,
    onOpenReminders: () -> Unit,
    onOpenGeminiHelp: () -> Unit,
    modifier: Modifier = Modifier
) {
    val animatedLevelProgress by animateFloatAsState(
        targetValue = userStats.levelProgress.coerceIn(0f, 1f),
        animationSpec = spring(stiffness = 300f),
        label = "xp_progress_anim"
    )

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = SurfaceWhite
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(EmeraldPrimary, EmeraldBright)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.LocalFireDepartment,
                            contentDescription = "StreakFlow logo",
                            tint = SurfaceWhite,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "StreakFlow",
                            style = MaterialTheme.typography.titleLarge,
                            color = InkPrimary
                        )
                        Text(
                            text = dateLabel,
                            style = MaterialTheme.typography.labelMedium,
                            color = InkSecondary
                        )
                    }
                }

                Box(contentAlignment = Alignment.TopEnd) {
                    Column(
                        horizontalAlignment = Alignment.End,
                        modifier = Modifier.testTag("streak_header_xp")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(999.dp))
                                .background(FlameSoft)
                                .border(1.dp, FlameOrange.copy(alpha = 0.25f), RoundedCornerShape(999.dp))
                                .padding(horizontal = 12.dp, vertical = 7.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Bolt,
                                contentDescription = "XP Points",
                                tint = FlameOrange,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Lvl ${userStats.level} - ${userStats.totalXp} XP",
                                fontFamily = JetBrainsMonoFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = FlameDeep
                            )
                        }
                        Spacer(modifier = Modifier.height(5.dp))
                        Box(
                            modifier = Modifier
                                .width(116.dp)
                                .height(4.dp)
                                .clip(CircleShape)
                                .background(SurfaceVariantLight)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(animatedLevelProgress)
                                    .height(4.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.horizontalGradient(
                                            colors = listOf(FlameOrange, EmeraldPrimary)
                                        )
                                    )
                            )
                        }
                    }

                    androidx.compose.animation.AnimatedVisibility(
                        visible = showXpBurst,
                        enter = fadeIn(tween(150)) + slideInVertically { it / 2 },
                        exit = fadeOut(tween(300)),
                        modifier = Modifier.padding(top = 42.dp, end = 6.dp)
                    ) {
                        Text(
                            text = "+$xpBurstAmount XP",
                            fontFamily = JetBrainsMonoFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = EmeraldPrimary,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(SurfaceWhite)
                                .border(1.dp, EmeraldPrimary.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            // Top Action Strip: +100 Bonus XP (Rewarded Ad), Ask Gemini Help, and Daily Reminder Bell
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .weight(1.25f)
                        .height(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(FlameSoft)
                        .border(1.dp, FlameOrange.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                        .clickable(enabled = !isBonusAdLoading, onClick = onWatchBonusXpAd)
                        .padding(horizontal = 10.dp)
                        .testTag("bonus_xp_ad_button")
                ) {
                    if (isBonusAdLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(15.dp),
                            strokeWidth = 2.dp,
                            color = FlameOrange
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Rounded.PlayCircle,
                            contentDescription = "Watch ad for +100 Bonus XP",
                            tint = FlameOrange,
                            modifier = Modifier.size(17.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isBonusAdLoading) "Loading Ad…" else "+100 Bonus XP",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = FlameDeep,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(IndigoSoft)
                        .border(1.dp, IndigoAccent.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
                        .clickable(onClick = onOpenGeminiHelp)
                        .padding(horizontal = 10.dp)
                        .testTag("header_gemini_help_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.AutoAwesome,
                        contentDescription = "Ask Gemini Help",
                        tint = IndigoAccent,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "Ask Gemini",
                        style = MaterialTheme.typography.labelMedium,
                        color = IndigoDeep,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(width = 48.dp, height = 40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (reminderSettings.enabled) EmeraldSoft.copy(alpha = 0.55f) else SurfaceVariantLight)
                        .border(
                            width = 1.dp,
                            color = if (reminderSettings.enabled) EmeraldPrimary.copy(alpha = 0.35f) else BorderHairline,
                            shape = RoundedCornerShape(12.dp)
                        )
                        .clickable(onClick = onOpenReminders)
                        .testTag("header_reminder_button")
                ) {
                    Icon(
                        imageVector = if (reminderSettings.enabled) {
                            Icons.Rounded.NotificationsActive
                        } else {
                            Icons.Outlined.Notifications
                        },
                        contentDescription = if (reminderSettings.enabled) {
                            "Daily reminder active at ${reminderSettings.formattedTime()}"
                        } else {
                            "Set Daily Habit Reminder"
                        },
                        tint = if (reminderSettings.enabled) EmeraldPrimary else InkSecondary,
                        modifier = Modifier.size(19.dp)
                    )
                }
            }

            HorizontalDivider(thickness = 1.dp, color = BorderHairline)
        }
    }
}
