package com.example.ui.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.QuitTimerEntity
import com.example.ui.theme.BorderHairline
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DangerSoft
import com.example.ui.theme.EmeraldBright
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.FlameDeep
import com.example.ui.theme.FlameOrange
import com.example.ui.theme.FlameSoft
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkPrimary
import com.example.ui.theme.InkSecondary
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.SurfaceVariantLight
import com.example.ui.theme.SurfaceWhite
import kotlinx.coroutines.delay
import java.util.Locale

@Composable
fun QuitTimerScreen(
    trackers: List<QuitTimerEntity>,
    activeTracker: QuitTimerEntity?,
    onSelectTracker: (Long) -> Unit,
    onResetTracker: (QuitTimerEntity) -> Unit,
    onAddTracker: (String) -> Unit,
    onDeleteTracker: (QuitTimerEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var nowMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var showResetDialog by remember { mutableStateOf(false) }
    var showAddDialog by remember { mutableStateOf(false) }

    LaunchedEffect(activeTracker?.id, activeTracker?.startTimestampMillis) {
        while (true) {
            nowMillis = System.currentTimeMillis()
            delay(500L)
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item(key = "quit_header") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.quit_timer_title),
                            style = MaterialTheme.typography.headlineMedium,
                            color = InkPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = stringResource(R.string.quit_timer_subtitle),
                            style = MaterialTheme.typography.bodyMedium,
                            color = InkSecondary
                        )
                    }
                    OutlinedButton(
                        onClick = { showAddDialog = true },
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("add_quit_tracker_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = null,
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = stringResource(R.string.add_quit_habit),
                            color = EmeraldPrimary,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }

            item(key = "tracker_selector") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    trackers.forEach { tracker ->
                        val selected = tracker.id == activeTracker?.id
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (selected) EmeraldSoft else SurfaceWhite)
                                .border(
                                    width = 1.dp,
                                    color = if (selected) EmeraldPrimary else BorderHairline,
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable { onSelectTracker(tracker.id) }
                                .padding(
                                    start = 14.dp,
                                    end = if (trackers.size > 1) 6.dp else 14.dp,
                                    top = 10.dp,
                                    bottom = 10.dp
                                )
                        ) {
                            Text(
                                text = tracker.habitName,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (selected) EmeraldDeep else InkSecondary
                            )
                            if (trackers.size > 1) {
                                Spacer(modifier = Modifier.width(4.dp))
                                IconButton(
                                    onClick = { onDeleteTracker(tracker) },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Close,
                                        contentDescription = "Remove ${tracker.habitName}",
                                        tint = if (selected) EmeraldDeep else InkMuted,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (activeTracker != null) {
                item(key = "stopwatch_card") {
                    val elapsedMillis = (nowMillis - activeTracker.startTimestampMillis).coerceAtLeast(0L)
                    val totalSeconds = elapsedMillis / 1000L
                    val days = totalSeconds / 86400L
                    val hours = (totalSeconds % 86400L) / 3600L
                    val minutes = (totalSeconds % 3600L) / 60L
                    val seconds = totalSeconds % 60L

                    val bestStreakMillis = maxOf(activeTracker.bestStreakMillis, elapsedMillis)

                    StopwatchHeroCard(
                        habitName = activeTracker.habitName,
                        days = days,
                        hours = hours,
                        minutes = minutes,
                        seconds = seconds,
                        elapsedMillis = elapsedMillis,
                        bestStreakMillis = bestStreakMillis,
                        onResetClick = { showResetDialog = true }
                    )
                }
            }
        }
    }

    if (showResetDialog && activeTracker != null) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            containerColor = SurfaceWhite,
            title = {
                Text(
                    text = stringResource(R.string.reset_confirm_title),
                    style = MaterialTheme.typography.titleLarge,
                    color = InkPrimary
                )
            },
            text = {
                Text(
                    text = stringResource(R.string.reset_confirm_message),
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onResetTracker(activeTracker)
                        showResetDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = DangerRed,
                        contentColor = SurfaceWhite
                    ),
                    modifier = Modifier.testTag("confirm_quit_reset_button")
                ) {
                    Text(stringResource(R.string.confirm_reset))
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text(stringResource(R.string.cancel), color = InkSecondary)
                }
            }
        )
    }

    if (showAddDialog) {
        AddQuitTrackerDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { name ->
                onAddTracker(name)
                showAddDialog = false
            }
        )
    }
}

@Composable
private fun StopwatchHeroCard(
    habitName: String,
    days: Long,
    hours: Long,
    minutes: Long,
    seconds: Long,
    elapsedMillis: Long,
    bestStreakMillis: Long,
    onResetClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "live_pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(900),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_dot"
    )

    val milestoneTargetHours = when {
        elapsedMillis < 24L * 3600_000L -> 24L
        elapsedMillis < 3L * 24L * 3600_000L -> 72L
        elapsedMillis < 7L * 24L * 3600_000L -> 168L
        elapsedMillis < 30L * 24L * 3600_000L -> 720L
        else -> 2160L
    }
    val milestoneLabel = when (milestoneTargetHours) {
        24L -> "24 Hours"
        72L -> "3 Days"
        168L -> "7 Days"
        720L -> "30 Days"
        else -> "90 Days"
    }
    val milestoneProgress = (elapsedMillis.toFloat() / (milestoneTargetHours * 3600_000f)).coerceIn(0f, 1f)

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("quit_stopwatch_card"),
        shape = RoundedCornerShape(24.dp),
        color = SurfaceWhite,
        shadowElevation = 2.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderHairline, RoundedCornerShape(24.dp))
                .padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.Shield,
                        contentDescription = null,
                        tint = EmeraldPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "CLEAN FROM",
                        style = MaterialTheme.typography.labelSmall,
                        color = InkSecondary
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(EmeraldSoft)
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .alpha(pulseAlpha)
                            .clip(CircleShape)
                            .background(EmeraldPrimary)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "LIVE",
                        fontFamily = JetBrainsMonoFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = EmeraldDeep
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = habitName,
                style = MaterialTheme.typography.displayLarge,
                color = InkPrimary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(22.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TimeUnitTile(
                    value = String.format(Locale.US, "%02d", days),
                    label = "DAYS",
                    isHighlighted = days > 0,
                    modifier = Modifier.weight(1f)
                )
                TimeUnitTile(
                    value = String.format(Locale.US, "%02d", hours),
                    label = "HOURS",
                    isHighlighted = false,
                    modifier = Modifier.weight(1f)
                )
                TimeUnitTile(
                    value = String.format(Locale.US, "%02d", minutes),
                    label = "MINS",
                    isHighlighted = false,
                    modifier = Modifier.weight(1f)
                )
                TimeUnitTile(
                    value = String.format(Locale.US, "%02d", seconds),
                    label = "SECS",
                    isHighlighted = true,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(22.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(SurfaceVariantLight)
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Next Milestone: $milestoneLabel",
                        style = MaterialTheme.typography.labelMedium,
                        color = InkPrimary
                    )
                    Text(
                        text = "${(milestoneProgress * 100).toInt()}%",
                        fontFamily = JetBrainsMonoFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = EmeraldPrimary
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { milestoneProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(CircleShape),
                    color = EmeraldBright,
                    trackColor = SurfaceWhite,
                    strokeCap = StrokeCap.Round
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(FlameSoft.copy(alpha = 0.7f))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.EmojiEvents,
                        contentDescription = null,
                        tint = FlameOrange,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Personal Best",
                        style = MaterialTheme.typography.labelLarge,
                        color = FlameDeep
                    )
                }
                Text(
                    text = formatCompactDuration(bestStreakMillis),
                    fontFamily = JetBrainsMonoFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = FlameDeep
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            OutlinedButton(
                onClick = onResetClick,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = DangerSoft.copy(alpha = 0.45f),
                    contentColor = DangerRed
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, DangerRed.copy(alpha = 0.35f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("quit_reset_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.Refresh,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.reset_timer),
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

@Composable
private fun TimeUnitTile(
    value: String,
    label: String,
    isHighlighted: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (isHighlighted) EmeraldSoft.copy(alpha = 0.5f) else SurfaceVariantLight)
            .border(
                width = 1.dp,
                color = if (isHighlighted) EmeraldPrimary.copy(alpha = 0.3f) else BorderHairline,
                shape = RoundedCornerShape(16.dp)
            )
            .padding(vertical = 14.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            fontFamily = JetBrainsMonoFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 26.sp,
            color = if (isHighlighted) EmeraldDeep else InkPrimary
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = if (isHighlighted) EmeraldPrimary else InkSecondary
        )
    }
}

@Composable
private fun AddQuitTrackerDialog(
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var name by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceWhite,
        title = {
            Text(
                text = "Track Habit to Quit",
                style = MaterialTheme.typography.titleLarge,
                color = InkPrimary
            )
        },
        text = {
            Column {
                Text(
                    text = "Start a live clean timer for a habit you want to leave behind.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkSecondary
                )
                Spacer(modifier = Modifier.height(14.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    placeholder = { Text("e.g., Sugary Drinks, Nail Biting") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Words,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            if (name.isNotBlank()) onConfirm(name)
                        }
                    ),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EmeraldPrimary,
                        unfocusedBorderColor = BorderHairline,
                        cursorColor = EmeraldPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("quit_habit_name_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { if (name.isNotBlank()) onConfirm(name) },
                enabled = name.isNotBlank(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = EmeraldPrimary,
                    contentColor = SurfaceWhite
                )
            ) {
                Text("Start Timer")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.cancel), color = InkSecondary)
            }
        }
    )
}

private fun formatCompactDuration(millis: Long): String {
    val totalSeconds = (millis / 1000L).coerceAtLeast(0L)
    val days = totalSeconds / 86400L
    val hours = (totalSeconds % 86400L) / 3600L
    val minutes = (totalSeconds % 3600L) / 60L
    val seconds = totalSeconds % 60L
    return String.format(Locale.US, "%dd %02dh %02dm %02ds", days, hours, minutes, seconds)
}
