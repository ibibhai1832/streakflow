package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val StreakFlowLightColorScheme = lightColorScheme(
    primary = EmeraldPrimary,
    onPrimary = SurfaceWhite,
    primaryContainer = EmeraldSoft,
    onPrimaryContainer = EmeraldDeep,
    secondary = FlameOrange,
    onSecondary = SurfaceWhite,
    secondaryContainer = FlameSoft,
    onSecondaryContainer = FlameDeep,
    tertiary = IndigoAccent,
    onTertiary = SurfaceWhite,
    tertiaryContainer = IndigoSoft,
    onTertiaryContainer = IndigoDeep,
    background = CanvasWhite,
    onBackground = InkPrimary,
    surface = SurfaceWhite,
    onSurface = InkPrimary,
    surfaceVariant = SurfaceVariantLight,
    onSurfaceVariant = InkSecondary,
    outline = BorderHairline,
    outlineVariant = BorderHairline,
    error = DangerRed,
    onError = SurfaceWhite,
    errorContainer = DangerSoft,
    onErrorContainer = DangerRed
)

val StreakFlowShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun StreakFlowTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = StreakFlowLightColorScheme,
        typography = StreakFlowTypography,
        shapes = StreakFlowShapes,
        content = content
    )
}
