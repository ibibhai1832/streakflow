package com.example.ads

import android.content.Context
import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.material3.HorizontalDivider
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.BorderHairline
import com.example.ui.theme.SurfaceWhite
import com.startapp.sdk.ads.banner.Banner
import com.startapp.sdk.ads.banner.BannerListener
import com.startapp.sdk.adsbase.Ad
import com.startapp.sdk.adsbase.StartAppAd
import com.startapp.sdk.adsbase.adlisteners.AdEventListener
import com.startapp.sdk.adsbase.adlisteners.VideoListener

private const val TAG = "StartIoAds"

@Composable
fun StartIoBannerBar(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(SurfaceWhite)
            .testTag("startio_banner_container")
    ) {
        HorizontalDivider(thickness = 1.dp, color = BorderHairline)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .defaultMinSize(minHeight = 50.dp)
                .padding(vertical = 2.dp),
            contentAlignment = Alignment.Center
        ) {
            AndroidView(
                modifier = Modifier.wrapContentSize(),
                factory = { ctx ->
                    Banner(ctx, object : BannerListener {
                        override fun onReceiveAd(banner: android.view.View?) {
                            Log.d(TAG, "Banner ad loaded.")
                        }

                        override fun onFailedToReceiveAd(banner: android.view.View?) {
                            Log.w(TAG, "Banner ad failed to load.")
                        }

                        override fun onImpression(banner: android.view.View?) = Unit

                        override fun onClick(banner: android.view.View?) = Unit
                    }).apply {
                        loadAd()
                    }
                }
            )
        }
    }
}

class RewardedVideoHelper(private val context: Context) {
    private var rewardedAd: StartAppAd? = null
    private var isPreloading = false

    fun preload() {
        if (isPreloading || rewardedAd?.isReady == true) return
        isPreloading = true
        val ad = StartAppAd(context)
        rewardedAd = ad
        ad.loadAd(StartAppAd.AdMode.REWARDED_VIDEO, object : AdEventListener {
            override fun onReceiveAd(adObj: Ad) {
                isPreloading = false
                Log.d(TAG, "Rewarded video preloaded.")
            }

            override fun onFailedToReceiveAd(adObj: Ad?) {
                isPreloading = false
                Log.w(TAG, "Rewarded video preload failed: ${adObj?.errorMessage}")
            }
        })
    }

    fun showOrLoadAndShow(
        onLoadingChanged: (Boolean) -> Unit,
        onRewardEarned: () -> Unit,
        onError: (String) -> Unit
    ) {
        val existing = rewardedAd
        if (existing != null && existing.isReady) {
            showAdInternal(existing, onRewardEarned)
            return
        }

        onLoadingChanged(true)
        val freshAd = StartAppAd(context)
        rewardedAd = freshAd
        freshAd.loadAd(StartAppAd.AdMode.REWARDED_VIDEO, object : AdEventListener {
            override fun onReceiveAd(adObj: Ad) {
                onLoadingChanged(false)
                showAdInternal(freshAd, onRewardEarned)
            }

            override fun onFailedToReceiveAd(adObj: Ad?) {
                onLoadingChanged(false)
                val reason = adObj?.errorMessage ?: "No rewarded video available right now."
                Log.w(TAG, "Rewarded video load failed: $reason")
                onError("Rewarded video unavailable right now. Please try again.")
            }
        })
    }

    private fun showAdInternal(
        ad: StartAppAd,
        onRewardEarned: () -> Unit
    ) {
        var rewarded = false
        ad.setVideoListener(VideoListener {
            if (!rewarded) {
                rewarded = true
                onRewardEarned()
            }
        })
        ad.showAd()
        rewardedAd = null
        preload()
    }
}
