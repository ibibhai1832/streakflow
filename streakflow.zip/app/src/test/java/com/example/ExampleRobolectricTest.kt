package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.StreakFlowDatabase
import com.example.data.local.UserStatsEntity
import com.example.data.model.GoalPackCatalog
import com.example.data.repository.StreakFlowRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var context: Context
    private lateinit var db: StreakFlowDatabase
    private lateinit var repository: StreakFlowRepository

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        context.getSharedPreferences("streakflow_prefs", Context.MODE_PRIVATE).edit().clear().commit()
        db = Room.inMemoryDatabaseBuilder(context, StreakFlowDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = StreakFlowRepository(db.streakFlowDao(), context)
    }

    @After
    fun teardown() {
        db.close()
    }

    @Test
    fun `app name matches StreakFlow`() {
        val appName = context.getString(R.string.app_name)
        assertEquals("StreakFlow", appName)
    }

    @Test
    fun `completing habit increases XP by 50 and increments streak`() = runTest {
        repository.ensureInitializedAndRollOverDay()
        val initialHabits = repository.habitsFlow.first()
        assertTrue(initialHabits.isNotEmpty())

        val targetHabit = initialHabits.first()
        val xpDelta = repository.toggleHabitCompletion(targetHabit)
        assertEquals(UserStatsEntity.XP_PER_HABIT, xpDelta)

        val updatedStats = repository.userStatsFlow.first()
        assertEquals(50, updatedStats.totalXp)
        assertEquals(1, updatedStats.level)

        val updatedHabit = repository.habitsFlow.first().first { it.id == targetHabit.id }
        assertTrue(updatedHabit.isCompletedToday)
        assertEquals(1, updatedHabit.streak)
    }

    @Test
    fun `starting goal pack adds habits without duplicating`() = runTest {
        repository.ensureInitializedAndRollOverDay()
        val weightLossPack = GoalPackCatalog.packs.first { it.id == "weight_loss" }

        val firstAddCount = repository.startGoalPack(weightLossPack)
        assertEquals(weightLossPack.habits.size, firstAddCount)

        val secondAddCount = repository.startGoalPack(weightLossPack)
        assertEquals(0, secondAddCount)
    }

    @Test
    fun `resetting quit timer preserves best streak and updates start timestamp`() = runTest {
        repository.ensureInitializedAndRollOverDay()
        val tracker = repository.quitTrackersFlow.first().first()
        val olderTracker = tracker.copy(startTimestampMillis = System.currentTimeMillis() - 10_000L)
        db.streakFlowDao().updateQuitTracker(olderTracker)

        repository.resetQuitTracker(olderTracker)
        val refreshed = repository.quitTrackersFlow.first().first { it.id == tracker.id }
        assertTrue(refreshed.bestStreakMillis >= 10_000L)
        assertTrue(refreshed.startTimestampMillis > olderTracker.startTimestampMillis)
    }
}
